# face-recognition-based-attendance-system  

Do visit my blog for better explanations: https://machinelearningprojects.net/face-recognition-based-attendance-system/

![alt text](ss.png)
